-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 04, 2015 at 12:04 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `arspam`
--

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

DROP TABLE IF EXISTS `classes`;
CREATE TABLE IF NOT EXISTS `classes` (
`id` int(11) NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
CREATE TABLE IF NOT EXISTS `countries` (
`id` int(11) NOT NULL,
  `name` text NOT NULL,
  `ISO` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `graph_classes_hourly`
--

DROP TABLE IF EXISTS `graph_classes_hourly`;
CREATE TABLE IF NOT EXISTS `graph_classes_hourly` (
`id` int(11) NOT NULL,
  `hour` datetime NOT NULL,
  `ABSTRACT` int(11) NOT NULL,
  `ADULT` int(11) NOT NULL,
  `ALLOWIP` int(11) NOT NULL,
  `ALLOWSENDER` int(11) NOT NULL,
  `ALLOWTEXT` int(11) NOT NULL,
  `BLOCKIP` int(11) NOT NULL,
  `BLOCKRULE` int(11) NOT NULL,
  `BLOCKSENDER` int(11) NOT NULL,
  `BLOCKTEXT` int(11) NOT NULL,
  `BULKMAIL` int(11) NOT NULL,
  `BULKMAILER` int(11) NOT NULL,
  `COUNTRYBAN` int(11) NOT NULL,
  `DELETED` int(11) NOT NULL,
  `GAMBLING` int(11) NOT NULL,
  `GENERAL` int(11) NOT NULL,
  `GETRICH` int(11) NOT NULL,
  `INSURANCE` int(11) NOT NULL,
  `INVALIDRECIP` int(11) NOT NULL,
  `MEDIATHEFT` int(11) NOT NULL,
  `MEDS` int(11) NOT NULL,
  `OBFUSCATION` int(11) NOT NULL,
  `OTHERSPAM` int(11) NOT NULL,
  `SPAM` int(11) NOT NULL,
  `SPAMWARE` int(11) NOT NULL,
  `TRAVEL` int(11) NOT NULL,
  `VALID` int(11) NOT NULL,
  `VIRUS` int(11) NOT NULL,
  `class` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `metadata`
--

DROP TABLE IF EXISTS `metadata`;
CREATE TABLE IF NOT EXISTS `metadata` (
`id` int(11) NOT NULL,
  `name` text NOT NULL,
  `period` datetime NOT NULL,
  `domainKey` text NOT NULL,
  `countsTotal` int(11) NOT NULL,
  `counts0` int(11) NOT NULL,
  `counts1` int(11) NOT NULL,
  `counts2` int(11) NOT NULL,
  `counts3` int(11) NOT NULL,
  `counts4` int(11) NOT NULL,
  `counts5` int(11) NOT NULL,
  `counts6` int(11) NOT NULL,
  `counts7` int(11) NOT NULL,
  `counts8` int(11) NOT NULL,
  `counts9` int(11) NOT NULL,
  `counts10` int(11) NOT NULL,
  `counts11` int(11) NOT NULL,
  `counts12` int(11) NOT NULL,
  `counts13` int(11) NOT NULL,
  `counts14` int(11) NOT NULL,
  `counts15` int(11) NOT NULL,
  `counts16` int(11) NOT NULL,
  `counts17` int(11) NOT NULL,
  `counts18` int(11) NOT NULL,
  `counts19` int(11) NOT NULL,
  `counts20` int(11) NOT NULL,
  `counts21` int(11) NOT NULL,
  `counts22` int(11) NOT NULL,
  `counts23` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9262 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `receivingip`
--

DROP TABLE IF EXISTS `receivingip`;
CREATE TABLE IF NOT EXISTS `receivingip` (
`id` int(11) NOT NULL,
  `ip` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `securetide`
--

DROP TABLE IF EXISTS `securetide`;
CREATE TABLE IF NOT EXISTS `securetide` (
`id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `class` int(3) NOT NULL,
  `message` char(36) NOT NULL,
  `sendingIP` varchar(15) NOT NULL,
  `receivingIP` int(3) NOT NULL,
  `country` int(3) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=50001 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tests`
--

DROP TABLE IF EXISTS `tests`;
CREATE TABLE IF NOT EXISTS `tests` (
`id` int(11) NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `test_fails`
--

DROP TABLE IF EXISTS `test_fails`;
CREATE TABLE IF NOT EXISTS `test_fails` (
`id` int(11) NOT NULL,
  `test` int(11) NOT NULL,
  `record` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=150955 DEFAULT CHARSET=utf8 COMMENT='relational for tests and securetide';

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_securetide`
--
DROP VIEW IF EXISTS `v_securetide`;
CREATE TABLE IF NOT EXISTS `v_securetide` (
`id` int(11)
,`date` datetime
,`className` text
,`message` char(36)
,`sendingIP` varchar(15)
,`receivingIP` text
,`country` text
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `v_test_fails`
--
DROP VIEW IF EXISTS `v_test_fails`;
CREATE TABLE IF NOT EXISTS `v_test_fails` (
`id` int(11)
,`record` int(11)
,`test` text
);
-- --------------------------------------------------------

--
-- Structure for view `v_securetide`
--
DROP TABLE IF EXISTS `v_securetide`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_securetide` AS select `s`.`id` AS `id`,`s`.`date` AS `date`,`cl`.`name` AS `className`,`s`.`message` AS `message`,`s`.`sendingIP` AS `sendingIP`,`r`.`ip` AS `receivingIP`,`co`.`name` AS `country` from (((`securetide` `s` join `classes` `cl`) join `countries` `co`) join `receivingip` `r`) where ((`cl`.`id` = `s`.`class`) and (`co`.`id` = `s`.`country`) and (`r`.`id` = `s`.`receivingIP`));

-- --------------------------------------------------------

--
-- Structure for view `v_test_fails`
--
DROP TABLE IF EXISTS `v_test_fails`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_test_fails` AS select `f`.`id` AS `id`,`f`.`record` AS `record`,`t`.`name` AS `test` from (`test_fails` `f` join `tests` `t`) where (`f`.`test` = `t`.`id`);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
 ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `graph_classes_hourly`
--
ALTER TABLE `graph_classes_hourly`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `metadata`
--
ALTER TABLE `metadata`
 ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `receivingip`
--
ALTER TABLE `receivingip`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `securetide`
--
ALTER TABLE `securetide`
 ADD UNIQUE KEY `id` (`id`), ADD KEY `class` (`class`), ADD KEY `country` (`country`), ADD KEY `receivingIP` (`receivingIP`);

--
-- Indexes for table `tests`
--
ALTER TABLE `tests`
 ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `test_fails`
--
ALTER TABLE `test_fails`
 ADD UNIQUE KEY `id` (`id`), ADD KEY `test` (`test`), ADD KEY `record` (`record`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=130;
--
-- AUTO_INCREMENT for table `graph_classes_hourly`
--
ALTER TABLE `graph_classes_hourly`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `metadata`
--
ALTER TABLE `metadata`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9262;
--
-- AUTO_INCREMENT for table `receivingip`
--
ALTER TABLE `receivingip`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `securetide`
--
ALTER TABLE `securetide`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=50001;
--
-- AUTO_INCREMENT for table `tests`
--
ALTER TABLE `tests`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=106;
--
-- AUTO_INCREMENT for table `test_fails`
--
ALTER TABLE `test_fails`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=150955;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `securetide`
--
ALTER TABLE `securetide`
ADD CONSTRAINT `securetide_ibfk_1` FOREIGN KEY (`class`) REFERENCES `classes` (`id`) ON UPDATE NO ACTION,
ADD CONSTRAINT `securetide_ibfk_2` FOREIGN KEY (`country`) REFERENCES `countries` (`id`) ON UPDATE NO ACTION,
ADD CONSTRAINT `securetide_ibfk_3` FOREIGN KEY (`receivingIP`) REFERENCES `receivingip` (`id`) ON UPDATE NO ACTION;

--
-- Constraints for table `test_fails`
--
ALTER TABLE `test_fails`
ADD CONSTRAINT `test_fails_ibfk_1` FOREIGN KEY (`test`) REFERENCES `tests` (`id`) ON UPDATE NO ACTION,
ADD CONSTRAINT `test_fails_ibfk_2` FOREIGN KEY (`record`) REFERENCES `securetide` (`id`) ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
