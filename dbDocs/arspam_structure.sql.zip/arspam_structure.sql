-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 08, 2015 at 09:23 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `arspam`
--

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
`id` int(11) NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `messageclasses`
--

CREATE TABLE IF NOT EXISTS `messageclasses` (
`id` int(11) NOT NULL,
  `class` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `metadata`
--

CREATE TABLE IF NOT EXISTS `metadata` (
`id` int(11) NOT NULL,
  `name` text NOT NULL,
  `period` datetime NOT NULL,
  `domainKey` text NOT NULL,
  `countsTotal` int(11) NOT NULL,
  `counts0` int(11) NOT NULL,
  `counts1` int(11) NOT NULL,
  `counts2` int(11) NOT NULL,
  `counts3` int(11) NOT NULL,
  `counts4` int(11) NOT NULL,
  `counts5` int(11) NOT NULL,
  `counts6` int(11) NOT NULL,
  `counts7` int(11) NOT NULL,
  `counts8` int(11) NOT NULL,
  `counts9` int(11) NOT NULL,
  `counts10` int(11) NOT NULL,
  `counts11` int(11) NOT NULL,
  `counts12` int(11) NOT NULL,
  `counts13` int(11) NOT NULL,
  `counts14` int(11) NOT NULL,
  `counts15` int(11) NOT NULL,
  `counts16` int(11) NOT NULL,
  `counts17` int(11) NOT NULL,
  `counts18` int(11) NOT NULL,
  `counts19` int(11) NOT NULL,
  `counts20` int(11) NOT NULL,
  `counts21` int(11) NOT NULL,
  `counts22` int(11) NOT NULL,
  `counts23` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9262 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `receivingip`
--

CREATE TABLE IF NOT EXISTS `receivingip` (
`id` int(11) NOT NULL,
  `ip` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `securetide`
--

CREATE TABLE IF NOT EXISTS `securetide` (
`id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `class` int(11) NOT NULL,
  `message` text NOT NULL,
  `sendingIP` text NOT NULL,
  `receivingIP` int(11) NOT NULL,
  `country` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=50001 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Stand-in structure for view `securetideview`
--
CREATE TABLE IF NOT EXISTS `securetideview` (
`id` int(11)
,`date` datetime
,`class` text
,`message` text
,`sendingIP` text
,`receivingIP` text
,`country` text
);
-- --------------------------------------------------------

--
-- Table structure for table `tests`
--

CREATE TABLE IF NOT EXISTS `tests` (
`id` int(11) NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `test_fails`
--

CREATE TABLE IF NOT EXISTS `test_fails` (
`id` int(11) NOT NULL,
  `test` int(11) NOT NULL,
  `record` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=150955 DEFAULT CHARSET=utf8 COMMENT='relational for tests and securetide';

-- --------------------------------------------------------

--
-- Structure for view `securetideview`
--
DROP TABLE IF EXISTS `securetideview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `securetideview` AS select `s`.`id` AS `id`,`s`.`date` AS `date`,`cl`.`class` AS `class`,`s`.`message` AS `message`,`s`.`sendingIP` AS `sendingIP`,`r`.`ip` AS `receivingIP`,`co`.`name` AS `country` from (((`securetide` `s` join `messageclasses` `cl`) join `countries` `co`) join `receivingip` `r`) where ((`cl`.`id` = `s`.`class`) and (`co`.`id` = `s`.`country`) and (`r`.`id` = `s`.`receivingIP`));

--
-- Indexes for dumped tables
--

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `messageclasses`
--
ALTER TABLE `messageclasses`
 ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `metadata`
--
ALTER TABLE `metadata`
 ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `receivingip`
--
ALTER TABLE `receivingip`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `securetide`
--
ALTER TABLE `securetide`
 ADD UNIQUE KEY `id` (`id`), ADD KEY `class` (`class`), ADD KEY `country` (`country`), ADD KEY `receivingIP` (`receivingIP`);

--
-- Indexes for table `tests`
--
ALTER TABLE `tests`
 ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `test_fails`
--
ALTER TABLE `test_fails`
 ADD UNIQUE KEY `id` (`id`), ADD KEY `test` (`test`), ADD KEY `record` (`record`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=130;
--
-- AUTO_INCREMENT for table `messageclasses`
--
ALTER TABLE `messageclasses`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `metadata`
--
ALTER TABLE `metadata`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9262;
--
-- AUTO_INCREMENT for table `receivingip`
--
ALTER TABLE `receivingip`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `securetide`
--
ALTER TABLE `securetide`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=50001;
--
-- AUTO_INCREMENT for table `tests`
--
ALTER TABLE `tests`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=106;
--
-- AUTO_INCREMENT for table `test_fails`
--
ALTER TABLE `test_fails`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=150955;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `securetide`
--
ALTER TABLE `securetide`
ADD CONSTRAINT `securetide_ibfk_1` FOREIGN KEY (`class`) REFERENCES `messageclasses` (`id`) ON UPDATE NO ACTION,
ADD CONSTRAINT `securetide_ibfk_2` FOREIGN KEY (`country`) REFERENCES `countries` (`id`) ON UPDATE NO ACTION,
ADD CONSTRAINT `securetide_ibfk_3` FOREIGN KEY (`receivingIP`) REFERENCES `receivingip` (`id`) ON UPDATE NO ACTION;

--
-- Constraints for table `test_fails`
--
ALTER TABLE `test_fails`
ADD CONSTRAINT `test_fails_ibfk_1` FOREIGN KEY (`test`) REFERENCES `tests` (`id`) ON UPDATE NO ACTION,
ADD CONSTRAINT `test_fails_ibfk_2` FOREIGN KEY (`record`) REFERENCES `securetide` (`id`) ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
